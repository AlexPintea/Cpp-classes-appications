
filepath=$PWD

for a in $filepath
do
	echo $a
done
