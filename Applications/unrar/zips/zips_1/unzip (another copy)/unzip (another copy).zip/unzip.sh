path="/home/account/C apl/unzip/zips"
cd "$path"

ls;
